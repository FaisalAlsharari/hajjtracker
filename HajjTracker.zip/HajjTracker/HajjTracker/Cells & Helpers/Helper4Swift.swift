//
//  Core.swift
//  Weddings
//
//  Created by Wafi Alshammari on 24/7/2018.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import Foundation
import UIKit
import ARSLineProgress
import Alamofire
import CoreData
import SDWebImage

public class Helper {
    
    func AppVerion (Status : Bool) -> String {
        var temp1 = "Error App version "
        var temp2 = "Error build version"
        var Content = ""
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String { temp1 = version }
        if let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String { temp2 = "\(build)" }
        if (Status == true) {Content = temp1} else {Content = temp2}
        return Content
    }
    
    func customFormatter (_ format : String) -> DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter
    }
    
    public static func showBasicAlert(title: String?, message: String?, buttonTitle: String?, isBlue: Bool, vc: UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        var action = UIAlertAction(title: buttonTitle, style: .default, handler: nil)
        if (isBlue == false) {action = UIAlertAction(title: buttonTitle, style: .destructive)}
        alert.addAction(action)
        vc.present(alert, animated: true)
    }
    
    public static func showErrorMessage (_ error : Error? ,_ line:Int, _ vc : UIViewController) {
        ARSLineProgress.showFail()
        showBasicAlert(title: "Error❌. VC:\(vc.description) Line:\(line) ", message: "اذا تكرر لك الخطأ راسلنا،\n \(String(describing: error))", buttonTitle: "موافق", isBlue: false, vc: vc)
        //a اقتراح: رسالة فيها زر اغلاق وزر إبلاغ مع محتوى الخطأ
    }
    
    class var isConnectedToInternet : Bool { return NetworkReachabilityManager()!.isReachable }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if (cString.hasPrefix("#")) {cString.remove(at: cString.startIndex)}
        if ((cString.count) != 6) {return UIColor.gray}
        var rgbValue:UInt32 = 0;
        Scanner(string: cString).scanHexInt32(&rgbValue)
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func resizeImageWith(image: UIImage, newSize: CGSize) -> UIImage {
        
        let horizontalRatio = newSize.width / image.size.width
        let verticalRatio = newSize.height / image.size.height
        
        let ratio = max(horizontalRatio, verticalRatio)
        let newSize = CGSize(width: image.size.width * ratio, height: image.size.height * ratio)
        var newImage: UIImage
        
        if #available(iOS 10.0, *) {
            let renderFormat = UIGraphicsImageRendererFormat.default()
            renderFormat.opaque = false
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: newSize.width, height: newSize.height), format: renderFormat)
            newImage = renderer.image {
                (context) in
                image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
            }
        } else {
            UIGraphicsBeginImageContextWithOptions(CGSize(width: newSize.width, height: newSize.height), true, 0)
            image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
            newImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
        }
        return newImage
    }
    
    
    func DeleteFromCoreData(_ entityName : String) {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let context = delegate.persistentContainer.viewContext
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
        } catch {
            print ("There was an error")
        }
    }
    
}

// Extensions

extension UIImageView {
    func loadImageUsingCache (_ urlString : String) {
        let size : CGFloat = 50
        let indicator = UIActivityIndicatorView()
        indicator.clipsToBounds = true
        indicator.hidesWhenStopped = true
        indicator.layer.backgroundColor = UIColor.black.cgColor
        indicator.layer.opacity = 0.4
        indicator.layer.cornerRadius = 10
        indicator.activityIndicatorViewStyle = .whiteLarge
        let position = (bounds.size.width / 2) - (size / 2)
        indicator.frame = CGRect.init(x: position, y: position, width: size, height: size)
        indicator.startAnimating()
        self.addSubview(indicator)
        if urlString == "Empty" {
            self.image = UIImage(named: "ClanImage")
            self.subviews.last?.removeFromSuperview()
        }else {
            // Download with cache From: Pod 'SDWebImage'
            self.sd_setImage(with: URL(string: urlString)) { (uiimage, error, sdImageCacheType, imageUrl) in
                self.subviews.last?.removeFromSuperview()
            }
        }
    }
}

public extension UITextField {
    @objc func dismissKeyboard(thisView: UIView) {self.endEditing(true)}
    
    public func addUnderlineDesign(borderColor: UIColor,borderWidth: CGFloat,masksToBounds: Bool) {
        
        let border = CALayer()
        border.borderColor = borderColor.cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - borderWidth, width:  self.frame.size.width, height: self.frame.size.height)
        border.borderWidth = borderWidth
        self.layer.addSublayer(border)
        self.layer.masksToBounds = masksToBounds
    }
    
    func setToolBar(doneTitle: String){
        var title = doneTitle; if title == "" {title = "Done"}
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let done = UIBarButtonItem(title: title, style: .done, target: nil, action: #selector(self.dismissKeyboard))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([flexibleSpace, done], animated: false)
        self.inputAccessoryView = toolbar
    }
    
}

public extension UITextView {
    @objc func dismissKeyboard(thisView: UIView) {self.endEditing(true)}
    
    func setToolBar(doneTitle: String){
        var title = doneTitle; if title == "" {title = "Done"}
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let done = UIBarButtonItem(title: title, style: .done, target: nil, action: #selector(self.dismissKeyboard))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([flexibleSpace, done], animated: false)
        self.inputAccessoryView = toolbar
    }
    
}

public extension UIButton {
    public func roundedButton(){ self.layer.cornerRadius = self.frame.height / 2; self.clipsToBounds = true }
    
    public func applyButtonDesign(title: String = "Button",
                                  titleColor: UIColor = .white,
                                  cornerRadius: CGFloat = 0.0,
                                  backgroundColor: UIColor = .blue,
                                  shadowColor: UIColor = .black,
                                  shadowRadius: CGFloat = 0.0,
                                  shadowOpacity: Float = 0.0) {
        
        self.setTitle(title, for: .normal)
        self.setTitleColor(titleColor, for: .normal)
        self.layer.cornerRadius = cornerRadius
        self.layer.backgroundColor = backgroundColor.cgColor
        self.layer.shadowColor = shadowColor.cgColor
        self.layer.shadowRadius = shadowRadius
        self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
    }
}

public extension String {
    
    /**
     Return true if the string matched an email format like "abdullah@alhaider.net" .
     *How to use :*
     Declare a variable or constant like ==> let email = "abc@efg.com".isValidEmail
     *Values :*
     `emailFormat` Passing a regulare expression string "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}".
     `emailPredicate` NSPredicate.
     - important: Regular expression is case sensitive.
     - returns: true.
     - Author: Abdullah Alhaider
     */
    public var isValidEmail: Bool {
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}" // This is a regular expression
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: self)
    }
    
    /* -------------------------------------------------------------------------------- */
    
    /**
     Return true if the string has only numbers "0123456789".
     *How to use :*
     Declare a variable or constant like ==> let number = "12345".isValidNumber
     *Values*
     `numberFormat` : Numbers regulare expression string "^[0-9]*$".
     `numberPredicate` : NSPredicate(format:"SELF MATCHES %@", numberFormat).
     - important: Regular expression is case sensitive.
     - returns: true.
     - Author:
     Abdullah Alhaider
     */
    
    public var isValidNumber: Bool {
        let numberFormat = "^[0-9]*$"
        let numberPredicate = NSPredicate(format:"SELF MATCHES %@", numberFormat)
        return numberPredicate.evaluate(with: self)
    }
    
    
    /* -------------------------------------------------------------------------------- */
    
    
    /**
     Return true if the string has minimum 8 characters, and at least one uppercase letter, and one lowercase letter and one number
     , You can see more on http://regexlib.com/Search.aspx?k=password
     *How to use :*
     Declare a variable or constant like ==> let password = "Gg123456".isValidPassword
     *Values*
     `passwordFormat` : Password regulare expression string "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$".
     `passwordPredicate` : NSPredicate(format:"SELF MATCHES %@", passwordFormat).
     - important: Regular expression is case sensitive.
     - returns: true.
     - Author: Abdullah Alhaider
     */
    
    public var isValidPassword: Bool {
        let passwordFormat = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$"
        let passwordPredicate = NSPredicate(format:"SELF MATCHES %@", passwordFormat)
        return passwordPredicate.evaluate(with: self)
    }
    
    
    /* -------------------------------------------------------------------------------- */
    /* -------------------------------------------------------------------------------- */
    /* -------------------------------------------------------------------------------- */
    
    
    /**
     Return true if the string is a valid url.
     *How to use :*
     Declare a variable or constant like ==> let url = "https://google.com".isValidUrl
     - returns: true.
     - Author: Abdullah Alhaider
     */
    
    public var isValidUrl: Bool {
        return URL(string: self) != nil
    }
    
    
    /* -------------------------------------------------------------------------------- */
    /* -------------------------------------------------------------------------------- */
    /* -------------------------------------------------------------------------------- */
    
    
    /**
     Replacing string with another string "aaa" => "ttt".
     *How to use :*
     replace(string: " ", replacement: "")
     *Values*
     `numberFormat` string.
     `numberPredicate` replacement.
     - returns: String .
     - Author: Abdullah Alhaider.
     */
    
    public func replace(string:String, replacement:String) -> String {
        return self.replacingOccurrences(of: string, with: replacement, options: NSString.CompareOptions.literal, range: nil)
    }
    
    
    /* -------------------------------------------------------------------------------- */
    
    /**
     Removing the white space in any string by calling removeWhitespace() after a string value.
     *How to use :*
     Declare a variable or constant like ==> let text = "H e l l o   W o r l d !".removeWhitespace()
     - returns: String with no white space in.
     - Author: Abdullah Alhaider.
     */
    
    public func removeWhitespace() -> String {
        return self.replace(string: " ", replacement: "")
    }
    
    /* -------------------------------------------------------------------------------- */
    
    /**
     Replacing string by another string .
     - returns: String.
     - Author: Abdullah Alhaider.
     */
    
    public func replaceString(existingString: String, replaceItWith: String ) -> String {
        return self.replace(string: existingString, replacement: replaceItWith)
    }
    
}

public extension UIView {
    
    /**
     Adds a vertical gradient layer with two **UIColors** to the **UIView**.
     - Parameter topColor: The top **UIColor**.
     - Parameter bottomColor: The bottom **UIColor**.
     */
    
    public func addVerticalGradientLayer(topColor:UIColor, bottomColor:UIColor) {
        let gradient = CAGradientLayer()
        gradient.frame = self.bounds
        gradient.colors = [
            topColor.cgColor,
            bottomColor.cgColor
        ]
        gradient.locations = [0.0, 1.0]
        gradient.startPoint = CGPoint(x: 0, y: 0)
        gradient.endPoint = CGPoint(x: 0, y: 1)
        self.layer.insertSublayer(gradient, at: 0)
    }
    
    // To use it in you viewDidLoad() -->> view.addVerticalGradientLayer(topColor: UIColor.black, bottomColor: UIColor.red)
    
    public func applyViewDesign(masksToBounds: Bool = false,
                                shadowColor: UIColor = .black,
                                cornerRadius: CGFloat = 0.0,
                                shadowOpacity: Float = 0.0,
                                shadowOffset: CGSize = CGSize(width: 0, height: 0),
                                shadowRadius: CGFloat = 0.0) {
        
        self.layer.masksToBounds = masksToBounds
        self.layer.shadowColor = shadowColor.cgColor
        self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowOffset = shadowOffset
        self.layer.shadowRadius = shadowRadius
        self.layer.cornerRadius = cornerRadius
        //self.layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        self.layer.shouldRasterize = false
        //self.layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
}

extension Date {
    /// Returns the amount of years from another date
    func years(from date: Date) -> Int {
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    /// Returns the amount of months from another date
    func months(from date: Date) -> Int {
        return Calendar.current.dateComponents([.month], from: date, to: self).month ?? 0
    }
    /// Returns the amount of weeks from another date
    func weeks(from date: Date) -> Int {
        return Calendar.current.dateComponents([.weekOfMonth], from: date, to: self).weekOfMonth ?? 0
    }
    /// Returns the amount of days from another date
    func days(from date: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: date, to: self).day ?? 0
    }
    /// Returns the amount of hours from another date
    func hours(from date: Date) -> Int {
        return Calendar.current.dateComponents([.hour], from: date, to: self).hour ?? 0
    }
    /// Returns the amount of minutes from another date
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    /// Returns the amount of seconds from another date
    func seconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    /// Returns the amount of nanoseconds from another date
    func nanoseconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.nanosecond], from: date, to: self).nanosecond ?? 0
    }
    /// Returns the a custom time interval description from another date
    func offset(from date: Date) -> String {
        if years(from: date)   > 0 { return "\(years(from: date))y"   }
        if months(from: date)  > 0 { return "\(months(from: date))M"  }
        if weeks(from: date)   > 0 { return "\(weeks(from: date))w"   }
        if days(from: date)    > 0 { return "\(days(from: date))d"    }
        if hours(from: date)   > 0 { return "\(hours(from: date))h"   }
        if minutes(from: date) > 0 { return "\(minutes(from: date))m" }
        if seconds(from: date) > 0 { return "\(seconds(from: date))s" }
        if nanoseconds(from: date) > 0 { return "\(nanoseconds(from: date))ns" }
        return ""
    }
}



