//
//  LostCell.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 2018‏/8‏/2.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import UIKit

class LostCell: UITableViewCell {
    
    @IBOutlet var Avatar: UIImageView!
    @IBOutlet var Name: UILabel!
    @IBOutlet var Distance: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
