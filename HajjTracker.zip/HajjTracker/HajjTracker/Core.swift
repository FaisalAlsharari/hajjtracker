//
//  Core.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 1/8/2018.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import Foundation
import UIKit
import FirebaseFirestore

let core = Core()
let languages : [String] = ["arabic","english"]
let db = Firestore.firestore().collection("users")

struct HajjStruct {
    var ID : String
    var HajjName : String
    var Nationality : String
    var LicenseMutawf : String?
    var Address : String?
    var Phone : String?
    var Email : String
    var longitude : String?
    var latitude : String?
}

class Core {
    
    let gradientLabel = [UIColor.red,UIColor.black]
    let arabicD : [String:String] = ["language":"العربية","chooseLanguage" : "اختر اللغة",
                                              "next":"التالي",
                                              "hajjTracker":"متعقب الحج",
                                              "welcome":"أهلاً بك في رحلة متعقب الحج",
                                              "hajjSignup":"تسجيل حاج",
                                              "MotawfSignup":"تسجيل مطوف",
                                              "signupLabel":"لديك حساب؟ سجل الدخول هنا",
                                              "login":"تسجيل الدخول",
                                              "nationality":"الجنسية",
                                              "address":"العنوان",
                                              "phone":"رقم الجوال",
                                              "signup":"تسجيل",
                                              "mutawfName":"اسم المطوف",
                                              "IDNumber":"",
                                              "companyName":"صاحب المؤسسة"]
    
// --------------------------------------------------------------------------------------------------------------------- //
    let englishD : [String:String] = ["language":"English","chooseLanguage" : "Chose languge",
                                              "next":"Next",
                                              "hajjTracker":"HajjTracker",
                                              "welcome":"Welcom to HajjTracker Trip",
                                              "hajjSignup":"Haj sign up",
                                              "MotawfSignup":"Mutawf sign up",
                                              "signupLabel":"You have already account? log in here",
                                              "login":"Login",
                                              "nationality":"Nationality",
                                              "address":"address",
                                              "phone":"phone",
                                              "signup":"signup",
                                              "mutawfName":"motwfname",
                                              "IDNumber":"ID Number",
                                              "companyName":"Company Name "]
    
    func languages () -> [[String:String]] {
        return [arabicD,englishD]
    }
}
