//
//  HajjPage.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 2/8/2018.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import FirebaseAuth
import ARSLineProgress

class HajjPage: UIViewController, UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate {
    @IBOutlet var Avatar: UIImageView!
    @IBOutlet var HajjName: UILabel!
    @IBOutlet var ID: UILabel!
    @IBOutlet var MutawfLicense: UILabel!
    @IBOutlet var mapKit: MKMapView!
    
    var hajj : HajjStruct? = nil
    var latitude : Double = 21.6149940
    var longitude : Double = 39.1564389
    var locationManager = CLLocationManager()
    let annotation = MKPointAnnotation()
    let annotationTwo = MKPointAnnotation()
    let saintPaulHospitalBC = MKPointAnnotation()
    let mkDistanceformatter = MKDistanceFormatter()
    let lengthFormatter = LengthFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        HajjName.text = hajj?.HajjName
//        ID.text = hajj?.ID
//        MutawfLicense.text = hajj?.LicenseMutawf
        mapKit.showsUserLocation = true
        
        if CLLocationManager.locationServicesEnabled() {
            if CLLocationManager.authorizationStatus() == .restricted ||
            CLLocationManager.authorizationStatus() == .denied ||
            CLLocationManager.authorizationStatus() == .notDetermined {locationManager.requestWhenInUseAuthorization()}
            locationManager.desiredAccuracy = 1.0
            locationManager.delegate = self
            locationManager.startUpdatingLocation()
        }else { print("Please turn on location service or GPS")}
        
        let location = CLLocationCoordinate2DMake(latitude, longitude)
        annotation.coordinate = location
        mapKit.addAnnotation(annotation)
        
    }
    
    @IBAction func Logout(_ sender: Any) {
        do {try Auth.auth().signOut()} catch let error {Helper.showErrorMessage(error, #line, self); return}
        ARSLineProgress.showSuccess()
        self.performSegue(withIdentifier: "SignoutSegue", sender: nil)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LostCell", for: indexPath) as! LostCell
        cell.Name.text = hajj?.HajjName
        return cell
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLatitude = locations[0].coordinate.latitude
        let userLongitude = locations[0].coordinate.longitude
        let currentLocation = CLLocationCoordinate2DMake(userLatitude, userLongitude)
        let region = MKCoordinateRegion(center: currentLocation, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        mapKit.setRegion(region, animated: true)
        
        let userLocation = CLLocation(latitude: userLatitude, longitude: userLongitude)
        let location = CLLocation(latitude: latitude, longitude: longitude)
        let distance = userLocation.distance(from: location)
        
        let distanceInt = Int(distance)
        print("userLocation = \(userLocation)")
        print("location = \(location)")
        print("distance = \(distanceInt)")
        
        if distanceInt > 999 {
            annotation.title = "\((distanceInt / 1000).description) km"
        }else {
            annotation.title = "\(distanceInt.description) m"
        }
        
        mapKit.addAnnotation(annotation)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Unable to access your current location \n \(error)")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {return 5}
    
}
