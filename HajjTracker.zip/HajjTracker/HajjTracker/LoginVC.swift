
//
//  LoginVC.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 2018‏/8‏/2.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class LoginVC: UIViewController {
    @IBOutlet var Email: UITextField!
    @IBOutlet var Password: UITextField!
    let uid = Auth.auth().currentUser?.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Email.setToolBar(doneTitle: "تم")
        Password.setToolBar(doneTitle: "تم")
    }

    @IBAction func Login(_ sender: Any) {
        if uid != nil {
            db.document(uid!).addSnapshotListener { (snapshot, error) in
                if error != nil { print(error ?? "no error"); return}
                if let doc = snapshot?.data() {
                    let type = doc["type"] as! String
                    if type == "hajj" {self.goToHajj(doc) }
                    else { self.goToMutawf(doc)}
                }
            }
        }
        Auth.auth().signIn(withEmail: Email.text!, password: Password.text!) { (result, error) in
            if error != nil { print(error ?? "no error"); return}
            
        }
    }
    
    
    func goToHajj (_ doc : [String:Any]) {
        self.performSegue(withIdentifier: "LoginToHajj", sender: doc)
    }
    
    func goToMutawf (_ doc : [String:Any]) {
        self.performSegue(withIdentifier: "LoginToMuatawf", sender: doc)
        
    }
}
