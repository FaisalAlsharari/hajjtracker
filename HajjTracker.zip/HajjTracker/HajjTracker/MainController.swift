//
//  MainController.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 2/8/2018
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import UIKit

class MainController: UIViewController {
    @IBOutlet var hajjTracker: UILabel!
    @IBOutlet var welcome: UILabel!
    @IBOutlet var hajjSignup: CustomButton!
    @IBOutlet var MotawfSignup: CustomButton!
    @IBOutlet var signupLabel: UIButton!
    
    var language : String = ""
    var dictionary : [String : String] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        language = UserDefaults.standard.string(forKey: "language") ?? "Empty"
        
        switch language {
        case "arabic":
            dictionary = core.arabicD
        case "english":
            dictionary = core.englishD
        default:
            break
        }
        hajjTracker.text = dictionary["hajjTracker"]
        welcome.text = dictionary["welcome"]
        hajjSignup.setTitle(dictionary["hajjSignup"], for: .normal)
        MotawfSignup.setTitle(dictionary["MotawfSignup"], for: .normal)
        signupLabel.setTitle(dictionary["signupLabel"], for: .normal)
    }
    
}
