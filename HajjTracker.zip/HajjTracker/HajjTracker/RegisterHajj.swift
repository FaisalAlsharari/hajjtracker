//
//  RegisterHajj.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 2018‏/8‏/2.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import UIKit
import FirebaseFirestore
import FirebaseAuth
import ARSLineProgress
import FirebaseFirestore

class RegisterHajj: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var ID: UITextField!
    @IBOutlet var HajjName: UITextField!
    @IBOutlet var Nationality: UITextField!
    @IBOutlet var LicenseMutawf: UITextField!
    @IBOutlet var Address: UITextField!
    @IBOutlet var Phone: UITextField!
    @IBOutlet var Email: UITextField!
    @IBOutlet var Password: UITextField!
    
    var hajj : HajjStruct? =  nil
    var doc : [String:String] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ID.setToolBar(doneTitle: "تم")
        HajjName.setToolBar(doneTitle: "تم")
        Nationality.setToolBar(doneTitle: "تم")
        LicenseMutawf.setToolBar(doneTitle: "تم")
        Address.setToolBar(doneTitle: "تم")
        Phone.setToolBar(doneTitle: "تم")
        Email.setToolBar(doneTitle: "تم")
        Password.setToolBar(doneTitle: "تم")
    }
    
    @IBAction func RegisterAction(_ sender: Any) {
        doc["id"] = ID.text
        doc["name"] = HajjName.text
        doc["address"] = Address.text
        doc["email"] = Email.text
        doc["nationality"] = Nationality.text
        doc["type"] = "hajj"
        
        ARSLineProgress.showWithPresentCompetionBlock {}
        hajj = HajjStruct(ID: ID.text!, HajjName: HajjName.text!, Nationality: Nationality.text!, LicenseMutawf: LicenseMutawf.text!, Address: Address.text!, Phone: Phone.text!, Email: Email.text!, longitude: "nil", latitude: "nil")
        
        Auth.auth().createUser(withEmail: Email.text!, password: Password.text!) { (result, error) in
            print("Registration completed")
            if error != nil {
                print(error ?? "no error")
                return
            }else {
                db.document((result?.user.uid)!).setData(self.doc)
                self.performSegue(withIdentifier: "RegsiterHajjToMain", sender: self.hajj)
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    
    override func viewWillDisappear(_ animated: Bool) {ARSLineProgress.hide()}
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let main = segue.destination as? HajjPage {
            let hajj = sender as! HajjStruct
            main.hajj = hajj
        }
    }
    
}
