//
//  ViewController.swift
//  HajjTracker
//
//  Created by Wafi Alshammari on 1/8/2018.
//  Copyright © 2018 Wafi AlShammari. All rights reserved.
//

import UIKit
import FirebaseAuth

class StartController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet var pickerView: UIPickerView!
    var auto = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.delegate = self
        autoLogin()
    }
    
    func autoLogin () {
        if let uid = Auth.auth().currentUser?.uid {
            db.document(uid).addSnapshotListener { (snapshot, error) in
                if let doc = snapshot?.data() {
                    self.auto = true
                    let type = doc["type"] as! String
                    var info : [Any] = []
                    info.append(type)
                    if type == "hajj" {
                        let hajj = HajjStruct(ID: doc["id"] as! String, HajjName: doc["name"] as! String, Nationality: doc["nationality"] as! String, LicenseMutawf: nil, Address: nil, Phone: nil, Email: doc["email"] as! String, longitude: doc["longitude"] as? String, latitude: doc["latitude"] as? String)
                        info.append(hajj)
                        self.performSegue(withIdentifier: "StartToHajj", sender: info)
                    }else {
                        self.performSegue(withIdentifier: "StartToMutawf", sender: info)
                    }
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if auto {
            let info = sender as! [Any]
            let type = info[0] as! String
            if type == "hajj" {
                if let page = segue.destination as? HajjPage {
                    let hajj = info[1] as! HajjStruct
                    page.hajj = hajj
                }
            }else {
                
            }
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {return 1}
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {return languages.count}
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return core.languages()[row]["language"]}
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        UserDefaults.standard.set(languages[row], forKey: "language")}
}

